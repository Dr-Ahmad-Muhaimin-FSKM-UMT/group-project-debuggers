/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author ACER
 */
public class CustomerModule {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
