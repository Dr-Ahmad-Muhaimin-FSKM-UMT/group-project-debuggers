package com.laundry.tests;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CustomerModuleTest {

    private static WebDriver driver;
    private static WebDriverWait wait;

    private static final String BASE_URL = "http://softwaretesting.umt.edu.my/dobidemo/index.php";
    private static final String CUSTOMER_PAGE = BASE_URL + "?page=customers";

    private static final String USERNAME = "team_k2_14";
    private static final String PASSWORD = "b4tur4k1t";

    // Data from your test case images
    private static final String VALID_CUSTOMER_NAME = "Umairah";
    private static final String VALID_PHONE = "01136651302";
    private static final String VALID_BALANCE = "0";

    private static final String INVALID_PHONE = "123ABC";
    private static final String EMPTY_NAME_PHONE = "031234567";
    private static final String SEARCH_UNKNOWN = "Unknown";

    private static final String UPDATED_PHONE = "0123456789";

    @BeforeAll
    public static void setup() {
        System.out.println("====================================================");
        System.out.println("        STARTING CUSTOMER MODULE TESTING             ");
        System.out.println("====================================================");

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        driver.get(BASE_URL);

        findVisible(By.name("username")).sendKeys(USERNAME);
        findVisible(By.name("password")).sendKeys(PASSWORD);

        WebElement loginButton = findClickable(
                By.xpath("//button[@type='submit']"),
                By.xpath("//input[@type='submit']")
        );

        safeClick(loginButton);
        sleep(1500);

        System.out.println("✓ Pre-condition: User logged in successfully.");
    }

    // ==========================================================
    // FR-101 / TS01-TC01
    // Test Input: Name: Umairah, Phone: 01136651302, Balance: 0
    // Expected Output: Customer successfully added
    // ==========================================================
    @Test
    @Order(1)
    public void testTC_CUST_01_AddValidCustomer() {
        addCustomer(VALID_CUSTOMER_NAME, VALID_PHONE, "Auto test customer", VALID_BALANCE);

        openCustomerPage();
        searchCustomer(VALID_CUSTOMER_NAME);

        Assertions.assertTrue(
                tableContains(VALID_CUSTOMER_NAME) && tableContains(VALID_PHONE),
                "DEFECT FOUND: Valid customer Umairah was not successfully added."
        );
    }

    // ==========================================================
    // FR-101 / TS01-TC01
    // Test Input: Name: "", Phone: 031234567
    // Expected Output: Validation error
    // ==========================================================
    @Test
    @Order(2)
    public void testTC_CUST_02_AddEmptyNameValidation() {
        openAddCustomerPage();

        WebElement nameField = findVisible(By.xpath("//input[@placeholder='Enter name']"));
        WebElement phoneField = findVisible(By.xpath("//input[@placeholder='Enter phone number']"));
        WebElement descriptionField = findVisible(By.xpath("//textarea[@placeholder='Enter description']"));
        WebElement balanceField = findBalanceField();

        nameField.clear();

        phoneField.clear();
        phoneField.sendKeys(EMPTY_NAME_PHONE);

        descriptionField.clear();
        descriptionField.sendKeys("Empty name validation test");

        balanceField.clear();
        balanceField.sendKeys("0");

        clickButtonByText("Add");
        sleep(1200);

        boolean validationShown = hasNativeValidationError(nameField)
                || pageContains("validation", "required", "error");

        openCustomerPage();
        searchCustomer(EMPTY_NAME_PHONE);

        boolean emptyNameWasAdded = tableContains(EMPTY_NAME_PHONE);

        Assertions.assertFalse(
                emptyNameWasAdded && !validationShown,
                "DEFECT FOUND: System allows blank Customer Name."
        );
    }

    // ==========================================================
    // FR-101 / TS01-TC01
    // Test Input: Phone: 123ABC
    // Expected Output: System rejects the input
    // ==========================================================
    @Test
    @Order(3)
    public void testTC_CUST_03_AddNonNumericPhoneValidation() {
        addCustomer("Invalid Phone Test", INVALID_PHONE, "Invalid phone validation test", "0");

        openCustomerPage();
        searchCustomer(INVALID_PHONE);

        Assertions.assertFalse(
                tableContains(INVALID_PHONE),
                "DEFECT FOUND: System allows non-numeric characters in Phone Number."
        );
    }

    // ==========================================================
    // FR-102 / TS01-TC02
    // Test Input: Sort descending
    // Expected Output: Customers sorted correctly
    // ==========================================================
    @Test
    @Order(4)
    public void testTC_CUST_04_SortBalanceDescending() {
        openCustomerPage();

        WebElement balanceHeader = findClickable(By.xpath("//th[contains(.,'Balance')]"));

        safeClick(balanceHeader);
        sleep(700);

        safeClick(balanceHeader);
        sleep(700);

        Assertions.assertTrue(
                isBalanceColumnDescending(),
                "DEFECT FOUND: Customers are not sorted correctly by Balance in descending order."
        );
    }

    // ==========================================================
    // FR-102 / TS01-TC02
    // Test Input: Keyword: Unknown
    // Expected Output: "No customer found" displayed
    // ==========================================================
    @Test
    @Order(5)
    public void testTC_CUST_05_SearchUnknownCustomer() {
        openCustomerPage();

        searchCustomer(SEARCH_UNKNOWN);

        boolean noCustomerFound = pageContains("no customer found", "no matching records", "no data available")
                || !tableContains(SEARCH_UNKNOWN);

        Assertions.assertTrue(
                noCustomerFound,
                "DEFECT FOUND: System does not display 'No customer found' for unknown keyword."
        );
    }

    // ==========================================================
    // FR-103 / TS01-TC03
    // Test Input: Customer ID: 2
    // Expected Output: Customer info and sales history displayed
    // ==========================================================
    @Test
    @Order(6)
    public void testTC_CUST_06_ViewCustomerDetailsAndSalesHistory() {
        openCustomerPage();

        String customerName = getCustomerNameFromRow(2);
        String customerPhone = getCustomerPhoneFromRow(2);

        clickCustomerRow(2);
        sleep(1500);

        boolean detailDisplayed = pageContains(customerName)
                || pageContains(customerPhone)
                || pageContains("customer", "balance", "category", "sales", "transaction", "history");

        Assertions.assertTrue(
                detailDisplayed,
                "DEFECT FOUND: Customer information and sales history are not displayed."
        );
    }

    // ==========================================================
    // FR-104 / TS01-TC04
    // Test Input: Sales count > threshold
    // Expected Output: Customer category updated automatically
    // ==========================================================
    @Test
    @Order(7)
    public void testTC_CUST_07_AutomaticCustomerCategorization() {
        openCustomerPage();

        boolean categoryColumnExists = pageContains("Category");

        boolean categoryValueExists = tableContains("New")
                || tableContains("Regular")
                || tableContains("VIP")
                || tableContains("Premium")
                || tableContains("Loyal")
                || tableContains("Normal");

        Assertions.assertTrue(
                categoryColumnExists && categoryValueExists,
                "DEFECT FOUND: Customer category is not displayed or not updated automatically."
        );
    }

    // ==========================================================
    // FR-105 / TS01-TC05
    // Test Input: Change phone number
    // Expected Output: Updated successfully
    // ==========================================================
    @Test
    @Order(8)
    public void testTC_CUST_08_UpdateCustomerPhoneNumber() {
        ensureCustomerExists();

        openUpdateCustomerPage(VALID_CUSTOMER_NAME);

        WebElement phoneField = findVisible(
                By.xpath("//input[@placeholder='Enter phone number']"),
                By.name("phone"),
                By.name("customer_phone")
        );

        phoneField.clear();
        phoneField.sendKeys(UPDATED_PHONE);

        clickSaveOrUpdateButton();
        sleep(1500);

        openCustomerPage();
        searchCustomer(VALID_CUSTOMER_NAME);

        Assertions.assertTrue(
                tableContains(UPDATED_PHONE),
                "DEFECT FOUND: Customer phone number was not updated successfully."
        );
    }

    // ==========================================================
    // FR-105 / TS01-TC05
    // Test Input: Empty required field
    // Expected Output: Validation error shown
    // ==========================================================
    @Test
    @Order(9)
    public void testTC_CUST_09_UpdateEmptyRequiredFieldValidation() {
        ensureCustomerExists();

        openUpdateCustomerPage(VALID_CUSTOMER_NAME);

        WebElement nameField = findVisible(
                By.xpath("//input[@placeholder='Enter name']"),
                By.name("name"),
                By.name("customer_name")
        );

        nameField.clear();

        clickSaveOrUpdateButton();
        sleep(1200);

        boolean validationShown = hasNativeValidationError(nameField)
                || pageContains("validation", "required", "error");

        Assertions.assertTrue(
                validationShown,
                "DEFECT FOUND: System does not show validation error for empty required field."
        );
    }

    // ==========================================================
    // Helper Methods
    // ==========================================================

    private static void openCustomerPage() {
        driver.get(CUSTOMER_PAGE);

        findVisible(
                By.xpath("//table"),
                By.xpath("//*[contains(.,'Customers')]")
        );

        sleep(500);
    }

    private static void openAddCustomerPage() {
        openCustomerPage();

        WebElement newButton = findClickable(
                By.xpath("//a[contains(.,'+ New')]"),
                By.xpath("//a[contains(.,'New')]"),
                By.xpath("//button[contains(.,'New')]"),
                By.xpath("//a[contains(@href,'add')]")
        );

        safeClick(newButton);
        sleep(800);

        findVisible(By.xpath("//input[@placeholder='Enter name']"));
    }

    private static void addCustomer(String name, String phone, String description, String balance) {
        openAddCustomerPage();

        WebElement nameField = findVisible(By.xpath("//input[@placeholder='Enter name']"));
        WebElement phoneField = findVisible(By.xpath("//input[@placeholder='Enter phone number']"));
        WebElement descriptionField = findVisible(By.xpath("//textarea[@placeholder='Enter description']"));
        WebElement balanceField = findBalanceField();

        nameField.clear();
        if (name != null && !name.isEmpty()) {
            nameField.sendKeys(name);
        }

        phoneField.clear();
        phoneField.sendKeys(phone);

        descriptionField.clear();
        descriptionField.sendKeys(description);

        balanceField.clear();
        balanceField.sendKeys(balance);

        clickButtonByText("Add");

        sleep(1500);
    }

    private static WebElement findBalanceField() {
        return findVisible(
                By.xpath("//label[contains(.,'Starting balance')]/following::input[1]"),
                By.xpath("//*[contains(.,'Starting balance')]/following::input[1]"),
                By.xpath("//span[normalize-space()='RM']/following::input[1]"),
                By.xpath("//input[@type='number']"),
                By.xpath("//input[contains(@value,'0')]")
        );
    }

    private static void searchCustomer(String keyword) {
        WebElement searchBox = findVisible(By.xpath("//input[@type='search']"));

        searchBox.clear();
        searchBox.sendKeys(keyword);

        sleep(1000);
    }

    private static String getCustomerNameFromRow(int rowNumber) {
        WebElement nameLink = findVisible(
                By.xpath("//table/tbody/tr[" + rowNumber + "]//td[1]//a[1]")
        );

        return nameLink.getText().trim();
    }

    private static String getCustomerPhoneFromRow(int rowNumber) {
        try {
            WebElement firstColumn = findVisible(
                    By.xpath("//table/tbody/tr[" + rowNumber + "]//td[1]")
            );

            return firstColumn.getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    private static void clickCustomerRow(int rowNumber) {
        WebElement customerLink = findClickable(
                By.xpath("//table/tbody/tr[" + rowNumber + "]//td[1]//a[1]"),
                By.xpath("//table/tbody/tr[" + rowNumber + "]//a[1]")
        );

        safeClick(customerLink);
    }

    private static void openUpdateCustomerPage(String customerName) {
        openCustomerPage();
        searchCustomer(customerName);

        WebElement customerLink = findClickable(
                By.xpath("//table//a[contains(.,'" + customerName + "')]"),
                By.xpath("//table//tr[contains(.,'" + customerName + "')]//a[1]")
        );

        safeClick(customerLink);
        sleep(1000);

        boolean updateClicked = clickButtonByTextIfExists("Update")
                || clickButtonByTextIfExists("Edit")
                || clickFirstElementIfExists(
                        By.xpath("//a[contains(@href,'update')]"),
                        By.xpath("//a[contains(@href,'edit')]"),
                        By.xpath("//a[contains(@class,'btn-warning')]"),
                        By.xpath("//button[contains(@class,'btn-warning')]"),
                        By.xpath("//i[contains(@class,'fa-edit')]/parent::*"),
                        By.xpath("//i[contains(@class,'glyphicon-edit')]/parent::*")
                );

        Assertions.assertTrue(
                updateClicked,
                "Update/Edit button was not found on customer details page."
        );

        sleep(800);

        findVisible(
                By.xpath("//input[@placeholder='Enter name']"),
                By.name("name"),
                By.name("customer_name")
        );
    }

    private static void clickSaveOrUpdateButton() {
        boolean clicked = clickButtonByTextIfExists("Save")
                || clickButtonByTextIfExists("Update")
                || clickButtonByTextIfExists("Submit")
                || clickFirstElementIfExists(
                        By.xpath("//button[@type='submit']"),
                        By.xpath("//input[@type='submit']"),
                        By.xpath("//button[contains(@class,'btn-info')]"),
                        By.xpath("//button[contains(@class,'btn-primary')]")
                );

        Assertions.assertTrue(clicked, "Save/Update button was not found.");
    }

    private static void ensureCustomerExists() {
        openCustomerPage();
        searchCustomer(VALID_CUSTOMER_NAME);

        if (!tableContains(VALID_CUSTOMER_NAME)) {
            addCustomer(VALID_CUSTOMER_NAME, VALID_PHONE, "Auto test customer", VALID_BALANCE);
        }
    }

    private static boolean isBalanceColumnDescending() {
        List<Double> balances = getBalanceValues();

        if (balances.size() <= 1) {
            return true;
        }

        for (int i = 0; i < balances.size() - 1; i++) {
            if (balances.get(i) < balances.get(i + 1)) {
                return false;
            }
        }

        return true;
    }

    private static List<Double> getBalanceValues() {
        List<Double> values = new ArrayList<>();

        try {
            List<WebElement> rows = driver.findElements(By.xpath("//table/tbody/tr"));

            for (WebElement row : rows) {
                List<WebElement> cells = row.findElements(By.tagName("td"));

                if (cells.size() >= 2) {
                    String raw = cells.get(1).getText()
                            .replace("RM", "")
                            .replace(",", "")
                            .trim();

                    if (!raw.isEmpty()) {
                        values.add(Double.parseDouble(raw));
                    }
                }
            }
        } catch (Exception ignored) {
        }

        return values;
    }

    private static boolean tableContains(String keyword) {
        String text = getTableText().toLowerCase();
        String key = keyword.toLowerCase();

        if (text.contains("no matching records") || text.contains("no data available")) {
            return false;
        }

        return text.contains(key);
    }

    private static String getTableText() {
        try {
            return findVisible(By.xpath("//table")).getText();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean pageContains(String... keywords) {
        String bodyText = "";

        try {
            bodyText = driver.findElement(By.tagName("body")).getText().toLowerCase();
        } catch (Exception ignored) {
        }

        String pageSource = driver.getPageSource().toLowerCase();

        for (String keyword : keywords) {
            String key = keyword.toLowerCase();

            if (bodyText.contains(key) || pageSource.contains(key)) {
                return true;
            }
        }

        return false;
    }

    private static boolean hasNativeValidationError(WebElement element) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;

            String validationMessage = String.valueOf(
                    js.executeScript("return arguments[0].validationMessage;", element)
            );

            return validationMessage != null && !validationMessage.trim().isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private static void clickButtonByText(String buttonText) {
        boolean clicked = clickButtonByTextIfExists(buttonText);

        if (!clicked) {
            throw new RuntimeException("Button not found: " + buttonText);
        }
    }

    private static boolean clickButtonByTextIfExists(String buttonText) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;

            Object result = js.executeScript(
                    "var text = arguments[0].toLowerCase();" +
                    "var elements = document.querySelectorAll('button, input[type=submit], a');" +
                    "for (var i = 0; i < elements.length; i++) {" +
                    "  var e = elements[i];" +
                    "  var label = (e.innerText || e.value || e.textContent || '').trim().toLowerCase();" +
                    "  if (label.indexOf(text) !== -1) {" +
                    "    e.scrollIntoView({block:'center'});" +
                    "    e.click();" +
                    "    return true;" +
                    "  }" +
                    "}" +
                    "return false;",
                    buttonText
            );

            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean clickFirstElementIfExists(By... locators) {
        for (By locator : locators) {
            try {
                List<WebElement> elements = driver.findElements(locator);

                for (WebElement element : elements) {
                    if (element.isDisplayed() && element.isEnabled()) {
                        safeClick(element);
                        return true;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        return false;
    }

    private static WebElement findVisible(By... locators) {
        long endTime = System.currentTimeMillis() + 15000;

        while (System.currentTimeMillis() < endTime) {
            for (By locator : locators) {
                try {
                    List<WebElement> elements = driver.findElements(locator);

                    for (WebElement element : elements) {
                        if (element.isDisplayed()) {
                            return element;
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            sleep(250);
        }

        throw new RuntimeException("Visible element not found.");
    }

    private static WebElement findClickable(By... locators) {
        long endTime = System.currentTimeMillis() + 15000;

        while (System.currentTimeMillis() < endTime) {
            for (By locator : locators) {
                try {
                    List<WebElement> elements = driver.findElements(locator);

                    for (WebElement element : elements) {
                        if (element.isDisplayed() && element.isEnabled()) {
                            return element;
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            sleep(250);
        }

        throw new RuntimeException("Clickable element not found.");
    }

    private static void safeClick(WebElement element) {
        try {
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block:'center'});", element
            );

            sleep(300);
            element.click();

        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }

    private static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("\n====================================================");
        System.out.println("              CUSTOMER TESTING COMPLETE              ");
        System.out.println("====================================================");

        if (driver != null) {
            driver.quit();
        }
    }
}