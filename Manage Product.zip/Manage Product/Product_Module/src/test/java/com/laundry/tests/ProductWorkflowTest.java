package com.laundry.tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProductWorkflowTest {

    static WebDriver driver;
    static WebDriverWait wait;

    @BeforeAll
    static void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @BeforeEach
    void loginOnly() throws InterruptedException {
        driver.get("http://softwaretesting.umt.edu.my/dobidemo/login.php");
        driver.findElement(By.id("username")).clear();
        driver.findElement(By.id("username")).sendKeys("team_k2_14"); 
        driver.findElement(By.id("password")).clear();
        driver.findElement(By.id("password")).sendKeys("b4tur4k1t");
        driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).click();
        Thread.sleep(2000);
    }

    void openAddProduct() throws InterruptedException {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-toggle='dropdown']")));
        dropdown.click();
        WebElement addProductLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@href,'page=view_product&do=add')]")));
        addProductLink.click();
    }

    void openProductList() throws InterruptedException {
        driver.get("http://softwaretesting.umt.edu.my/dobidemo/index.php?page=products");
        Thread.sleep(2000);
    }

    private boolean fillAndSubmitProduct(String name, String unit, String price) throws InterruptedException {
        openAddProduct();
        
        WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("product_name")));
        nameField.clear();
        if (name != null && !name.isEmpty()) nameField.sendKeys(name);

        WebElement unitField = driver.findElement(By.name("product_unit"));
        unitField.clear();
        if (unit != null) unitField.sendKeys(unit);

        WebElement priceField = driver.findElement(By.name("product_unitprice"));
        priceField.clear();
        if (price != null) priceField.sendKeys(price);

        driver.findElement(By.name("addRecord")).click();
        
        // Menstabilkan ujian: Tunggu sehingga URL bertukar ke halaman senarai produk
        try {
            wait.until(ExpectedConditions.urlContains("page=products"));
            return true; 
        } catch (Exception e) {
            return false; 
        }
    }

    /*
     * ========================================================
     * 2.3.1 [FR-501] Add New Product Workflow (T505-TC01)
     * ========================================================
     */
    @Test
    @Order(1)
    void testTC_PROD_01_AddValidProduct() throws InterruptedException {
        boolean isAdded = fillAndSubmitProduct("Detergent Powder", "kg", "4.00");
        assertTrue(isAdded, "System should allow adding a valid product.");
    }

    @Test
    @Order(2)
    void testTC_PROD_02_AddEmptyNameValidation() throws InterruptedException {
        boolean isAdded = fillAndSubmitProduct("", "kg", "5.00");
        assertFalse(isAdded, "DEFECT FOUND: System allows blank Product Name."); 
    }

    @Test
    @Order(3)
    void testTC_PROD_03_AddNegativePriceValidation() throws InterruptedException {
        boolean isAdded = fillAndSubmitProduct("Soap Negative", "pcs", "-3.00");
        assertFalse(isAdded, "DEFECT FOUND: System allows negative unit prices.");
    }

    /*
     * =======================================================
     * 2.3.2 [FR-502] Sort and Search Product Workflow (T505-TC02)
     * =======================================================
     */
    @Test
    @Order(4)
    void testTC_PROD_04_StandardProductSearch() throws InterruptedException {
        openProductList();
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='search']")));
        searchBox.clear();
        searchBox.sendKeys("A");
        Thread.sleep(1000);
        assertFalse(driver.findElements(By.xpath("//table/tbody/tr")).isEmpty(), "Products matching 'A' should be displayed.");
    }

    @Test
    @Order(5)
    void testTC_PROD_04B_SortByNameAlphabetical() throws InterruptedException {
        openProductList();
        WebElement nameHeader = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//th[contains(text(),'Product Name') or contains(text(),'Name')]")));
        nameHeader.click();
        Thread.sleep(1500);
        
        assertFalse(driver.findElements(By.xpath("//table/tbody/tr")).isEmpty(), "Product list should display items after sorting by Name.");
    }

    @Test
    @Order(6)
    void testTC_PROD_04C_SortByPriceUnit() throws InterruptedException {
        openProductList();
        WebElement priceHeader = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//th[contains(text(),'Price/Unit') or contains(text(),'Price')]")));
        priceHeader.click();
        Thread.sleep(1500);
        
        assertFalse(driver.findElements(By.xpath("//table/tbody/tr")).isEmpty(), "Product list should display items after sorting by Price/Unit.");
    }

    /*
     * ========================================================
     * 2.3.3 [FR-503] View Details (T505-TC03)
     * ========================================================
     */
    @Test
    @Order(7)
    void testTC_PROD_05_ViewProductDetails() throws InterruptedException {
        openProductList();
        
        // Mencari secara dinamik baris produk spesifik "Aqua Dry Cleaning (Baju Kurung)"
        WebElement targetProductLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//table/tbody/tr[td[contains(normalize-space(), 'Aqua Dry Cleaning (Baju Kurung)')]]//a")
        ));
        targetProductLink.click();
        Thread.sleep(2000);

        assertTrue(driver.getPageSource().contains("Product Info") || driver.getCurrentUrl().contains("view_product"), 
                "Product details page failed to load.");
    }

    /*
     * ==================================================================================
     * 2.3.4 [FR-504] Update Details (T505-TC04)
     * ==================================================================================
     */
    private void navigateToUpdateForm() throws InterruptedException {
        openProductList();
        WebElement firstLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[1]//a")));
        firstLink.click();
        
        WebElement updateBtn = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Update")));
        updateBtn.click();
    }

    @Test
    @Order(8)
    void testTC_PROD_06A_UpdatePriceValid() throws InterruptedException {
        System.out.println("Melaksanakan: Kemas Kini Harga (RM4.00 -> RM7.00)...");
        navigateToUpdateForm();

        WebElement priceField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("product_unitprice")));
        priceField.clear();
        priceField.sendKeys("7.00"); 
        
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(2000);

        openProductList();
        boolean isUpdated = driver.getPageSource().contains("7.00");
        
        // Jangkaan: SUCCESS (true). Sistem DobiDemo yang rosak akan menghasilkan bar MERAH (Failed) sebagai bukti defect.
        assertTrue(isUpdated, "DEFECT DETECTED: Sistem gagal mengemas kini harga yang sah kepada RM7.00.");
    }

    @Test
    @Order(9)
    void testTC_PROD_06B_UpdateUnitValid() throws InterruptedException {
        System.out.println("Melaksanakan: Kemas Kini Unit (kg -> liter)...");
        navigateToUpdateForm();

        WebElement unitField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("product_unit")));
        unitField.clear();
        unitField.sendKeys("liter"); 
        
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(2000);

        openProductList();
        boolean isUpdated = driver.getPageSource().contains("liter");
        
        // Jangkaan: SUCCESS (true). Sistem DobiDemo yang rosak akan menghasilkan bar MERAH (Failed).
        assertTrue(isUpdated, "DEFECT DETECTED: Sistem gagal mengemas kini unit yang sah kepada 'liter'.");
    }

    @Test
    @Order(10)
    void testTC_PROD_06C_UpdatePriceNegative() throws InterruptedException {
        System.out.println("Melaksanakan: Kemas Kini Harga Negatif (RM4.00 -> -5.00)...");
        navigateToUpdateForm();

        WebElement priceField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("product_unitprice")));
        priceField.clear();
        priceField.sendKeys("-5.00"); 
        
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(2000);

        openProductList();
        boolean isUpdated = driver.getPageSource().contains("-5.00");
        
        // Jangkaan Logik QA: REJECT (false). Jika sistem meloloskan harga negatif (true), assert ini akan mengeluarkan bar MERAH (Defect Found).
        assertFalse(isUpdated, "DEFECT DETECTED: Sistem gagal menyekat nilai harga negatif sewaktu kemas kini.");
    }

    @Test
    @Order(11)
    void testTC_PROD_06D_UpdateNameNull() throws InterruptedException {
        System.out.println("Melaksanakan: Kemas Kini Nama Kosong (Product Name -> null)...");
        navigateToUpdateForm();

        WebElement nameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("product_name")));
        nameField.clear(); 
        
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(2000);

        openProductList();
        boolean hasBlankName = driver.getPageSource().contains("<td></td>") || driver.getPageSource().contains("<td> </td>");
        
        // Jangkaan Logik QA: REJECT (false). Jika sistem meloloskan nama kosong (true), ia akan menghasilkan bar MERAH (Defect Found).
        assertFalse(hasBlankName, "DEFECT DETECTED: Sistem gagal menyekat pengemaskinian nama produk menjadi kosong.");
    }

    @AfterAll
    static void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}