package com.mycompany.dobidemosuppliertesting;

import java.time.Duration;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SupplierWorkflowTest {

    private static WebDriver driver;
    private static WebDriverWait wait;

    private static final String BASE_URL =
            "http://softwaretesting.umt.edu.my/dobidemo/index.php";

    private static final String USERNAME = "team_k2_14";
    private static final String PASSWORD = "b4tur4k1t";

    @BeforeAll
    public static void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        wait = new WebDriverWait(driver, Duration.ofSeconds(8));

        driver.get(BASE_URL);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")))
                .sendKeys(USERNAME);

        driver.findElement(By.name("password")).sendKeys(PASSWORD);
        driver.findElement(By.xpath("//button[@type='submit']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("body")));

        System.out.println("Login completed.");
    }

    private void goToSupplierPage() {
        driver.navigate().to(BASE_URL + "?page=suppliers");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("body")));
    }

    @ParameterizedTest
    @MethodSource("addSupplierData")
    @Order(1)
    public void TC01_AddSupplier(String name, String phone, String description, String balance, String expectedResult) {
        System.out.println("\n[TC01] Add Supplier Test Running");
        goToSupplierPage();
        clickNewButton();
        fillSupplierAddForm(name, phone, description, balance);
        clickSubmitButton();

        String page = driver.getPageSource().toLowerCase();

        Assertions.assertTrue(page.contains("supplier") || page.contains("success"));
    }

    static Stream<Arguments> addSupplierData() {
        return Stream.of(
                Arguments.of("UMT Supply", "012345789", "electronics vendor", "150", "SUCCESS"),
                Arguments.of("", "012345789", "electronics vendor", "150", "EMPTY_NAME")
        );
    }

    @ParameterizedTest
    @MethodSource("viewSortSearchData")
    @Order(2)
    public void TC02_ViewSortAndSearchSupplier(String action, String keyword, String expected) {
        goToSupplierPage();
        Assertions.assertTrue(driver.getPageSource().length() > 0);
    }

    static Stream<Arguments> viewSortSearchData() {
        return Stream.of(
                Arguments.of("SORT_AZ", "", "SORTED_AZ"),
                Arguments.of("SEARCH", "Dobi", "MATCH_FOUND")
        );
    }

    @ParameterizedTest
    @MethodSource("supplierDetailsData")
    @Order(3)
    public void TC03_ViewSupplierDetails(String id, String expected) {
        goToSupplierPage();
        Assertions.assertTrue(driver.getPageSource().contains("supplier"));
    }

    static Stream<Arguments> supplierDetailsData() {
        return Stream.of(
                Arguments.of("1", "DETAILS_FOUND"),
                Arguments.of("999", "NOT_FOUND")
        );
    }

    @ParameterizedTest(name = "{index} => name={0}, phone={1}, desc={2}, balance={3}")
    @MethodSource("tc04Data")
    @Order(4)
    public void TC04_UpdateSupplier(String name, String phone, String desc, String balance) {

        System.out.println("\n[TC04] Running Update Supplier Test");

        goToSupplierPage();

        WebDriverWait localWait = new WebDriverWait(driver, Duration.ofSeconds(15));

        localWait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table")));

        WebElement firstSupplier = null;

        try {
            firstSupplier = driver.findElement(By.xpath("//table//tbody//tr[1]//a | //table//tbody//tr[1]"));
            firstSupplier.click();
        } catch (Exception e) {
            Assertions.fail("Cannot open supplier detail page");
        }

        localWait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

        WebElement editBtn = null;

        List<By> editLocators = List.of(
                By.xpath("//a[contains(.,'Edit')]"),
                By.xpath("//button[contains(.,'Edit')]"),
                By.xpath("//i[contains(@class,'edit')]"),
                By.xpath("//a[contains(@href,'edit')]"),
                By.xpath("//button[contains(@onclick,'edit')]")
        );

        for (By by : editLocators) {
            List<WebElement> els = driver.findElements(by);
            if (!els.isEmpty()) {
                editBtn = els.get(0);
                break;
            }
        }

        if (editBtn == null) {
            Assertions.fail("Edit button not found on supplier detail page");
        }

        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", editBtn);

        localWait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//form | //input | //textarea")
        ));
        
        List<WebElement> fields = driver.findElements(
                By.xpath("//input[not(@type='hidden') and not(@disabled)] | //textarea")
        );

        if (fields.isEmpty()) {
            Assertions.fail("No editable field found in update form");
        }

        String[] data = {name, phone, desc, balance};

        int i = 0;

        for (WebElement el : fields) {

            if (i >= data.length) break;

            try {
                if (el.isDisplayed() && el.isEnabled()) {
                    el.clear();
                    el.sendKeys(data[i]);
                    i++;
                }
            } catch (Exception ignored) {}
        }

        try {
            WebElement saveBtn = localWait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(.,'Save')] | //button[@type='submit'] | //input[@type='submit']")
            ));
            saveBtn.click();
        } catch (Exception e) {
            Assertions.fail("Save button not found");
        }

        System.out.println("TC04 completed successfully");
    }


    static Stream<Arguments> tc04Data() {
        return Stream.of(
                Arguments.of("Dobi Detergent Sdn Bhd", "0123456789", "updated supplier info", "50"),
                Arguments.of("Updated Supplier", "0129876543", "updated supplier info", "50"),
                Arguments.of("", "0129876543", "updated supplier info", "50")
        );
    }


    private void clickNewButton() {
        driver.findElement(By.xpath("//button[contains(.,'New') or contains(.,'Add')]")).click();
    }

    private void clickSubmitButton() {
        driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    private void fillSupplierAddForm(String name, String phone, String description, String balance) {
        List<WebElement> fields = driver.findElements(By.xpath("//input | //textarea"));

        String[] data = {name, phone, description, balance};
        int i = 0;

        for (WebElement f : fields) {
            if (i < data.length && f.isDisplayed()) {
                f.clear();
                f.sendKeys(data[i++]);
            }
        }
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("Done");
        driver.quit();
    }
}