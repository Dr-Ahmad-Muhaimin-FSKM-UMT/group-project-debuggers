/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dobidemosuppliertesting;

/**
 *
 * @author user
 */
public class DobiDemoSupplierTesting {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
