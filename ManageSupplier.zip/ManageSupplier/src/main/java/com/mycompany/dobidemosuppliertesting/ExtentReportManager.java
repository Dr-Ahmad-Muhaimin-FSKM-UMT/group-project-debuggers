package com.mycompany.dobidemosuppliertesting;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportManager {

    public static ExtentReports extent;
    public static ExtentTest test;

    public static void initReport() {
        ExtentSparkReporter reporter =
                new ExtentSparkReporter("test-output/SupplierReport.html");

        extent = new ExtentReports();
        extent.attachReporter(reporter);

        extent.setSystemInfo("Project", "DobiDemoSupplierTesting");
        extent.setSystemInfo("Tester", "Automation User");
    }

    public static void flushReport() {
        extent.flush();
    }
}